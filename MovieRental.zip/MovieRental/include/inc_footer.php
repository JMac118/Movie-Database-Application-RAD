<?php
/**
 * PHP Version 5
 *
 * @inc_footer.php
 * Footer file
 * @category       MovieRentalSearch
 * @package        MovieRentalSearch
 * @author         JoshuaMacaulay <30008704@tafe.wa.edu.au>
 * @license        https://www.gnu.org/licenses/gpl-3.0.en.html GPL
 * @link           nolink
 */
?>

<p class="footerP">&copy;2020 Copyright Team A. Developed by Sam, Aashiyan, Josh.</p>
