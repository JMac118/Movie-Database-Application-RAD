<?php
/**
 * PHP Version 5
 *
 * @db_credentials.php
 * Defines the database credentials
 * @category           MembershipManagement
 * @package            MembershipManagement
 * @author             JoshuaMacaulay <30008704@tafe.wa.edu.au>
 * @license            https://www.gnu.org/licenses/gpl-3.0.en.html GPL
 * @link               nolink
 */

define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "movie_rental");

?>
